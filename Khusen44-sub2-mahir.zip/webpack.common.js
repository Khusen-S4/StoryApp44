const path = require("path");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const CopyWebpackPlugin = require("copy-webpack-plugin"); // ⬅️ TAMBAHKAN

module.exports = {
  entry: {
    app: path.resolve(__dirname, "src/scripts/index.js"),
  },

  output: {
    filename: "[name].bundle.js",
    path: path.resolve(__dirname, "dist"),
    publicPath: "/StoryApp44/",
    clean: true,
    assetModuleFilename: "images/[name][ext]",
  },

  module: {
    rules: [
      {
        test: /\.css$/,
        use: ["style-loader", "css-loader"],
      },
      {
        test: /\.(png|jpe?g|gif|svg)$/i,
        type: "asset/resource",
      },
    ],
  },

  plugins: [
    new HtmlWebpackPlugin({
      template: path.resolve(__dirname, "src/index.html"),
    }),

    // ⬇️ INI BAGIAN PENTING
    new CopyWebpackPlugin({
      patterns: [
        { from: "src/public/sw.js", to: "sw.js" },
        { from: "src/public", to: ""}
      ],
    }),
  ],

  resolve: {
    extensions: [".js"],
  },
};
